#! /bin/sh

echo "Stop application modules......"
killall smon stunnel

sleep 3

echo "Install package......"
BIN_DIR="/usr/local/sunlight"
if !( test -e $BIN_DIR)
then 
    mkdir $BIN_DIR
fi

tar zxvf ./stunnel.tar.gz -C $BIN_DIR
cd $BIN_DIR
chown root:root stunnel
chmod 755 stunnel

CONF_DIR=$BIN_DIR"/conf"
if !( test -e $CONF_DIR)
then 
    mkdir $CONF_DIR
fi

STUNNEL_CONF_FILE=$CONF_DIR"/stunnel.conf"

if !( test -e $STUNNEL_CONF_FILE )
then
    HOST_ID="0"
    while [ $HOST_ID -lt 100 ]
    do
        printf "[Host ID]:  "
        read HOST_ID
        if ( test -z $HOST_ID )
        then
            HOST_ID="0"
            continue
        fi
    
        ret=$(expr match $HOST_ID "[0-9][0-9]*$")
        if [ $ret -eq 0 ]
        then
            echo "ERROR: Host ID must be digital number."
            echo ""
            HOST_ID="0"
            continue
        fi
        
        if [ $HOST_ID -lt 100 ]
        then
            echo "ERROR: Host ID must be greater than 100."
            echo ""
            continue
        fi
    done
    
    touch $STUNNEL_CONF_FILE
    
    echo "master_mode=0" > $STUNNEL_CONF_FILE 
    echo "master_host_name=218.17.162.117,115.28.104.91,112.80.41.151" >> $STUNNEL_CONF_FILE
    echo "host_id="$HOST_ID >> $STUNNEL_CONF_FILE
fi

PROC_LIST=$BIN_DIR"/proc_list"
touch $PROC_LIST

STUNNEL_PROC=$BIN_DIR"/stunnel"
if ( test -e $STUNNEL_PROC )
then
    sed -i '/\/usr\/local\/sunlight\/stunnel /d' $PROC_LIST
    echo "root /usr/local/sunlight/stunnel /usr/local/sunlight/stunnel -d" >> $PROC_LIST
else
    echo "Not found stunnel binary file, install procedure abort!"
    exit 3
fi

echo "Installation finished!"

echo ""
echo "Starting stunnel ......"

MONITOR_BIN="/usr/local/sunlight/smon"
if ( test -e $MONITOR_BIN )
then
    sudo $MONITOR_BIN -f $PROC_LIST
else
    sudo $STUNNEL_PROC -d
fi

echo "Start done!"
