#!/bin/sh

if [ $# -lt 1 ];then
	echo "$0 <ip>"
	exit 1
fi

ip=$1
keyword=cibn
port=5050

./exp/check_adb.exp $ip:$port
ret=$?
if [ $ret -eq 2 ];then
	echo "connect ret $ret"
	exit 2
fi

if [ $ret -eq 1 ];then
	./exp/open_port.exp $ip $port
	if [ $? -eq 1 ];then
		echo "open adb port failed on $ip"
		exit 3
	fi
	./exp/check_adb.exp $ip:$port
	if [ $? -ne 0 ];then
	# something is wrong ...
		echo "connect $ip failed"
		exit 4
	fi
fi

usleep 200000

echo -n "$ip   "
content=`./adb -s $ip:$port shell ps |grep $keyword`
found=$?
if [ $found -ne 0 ];then
        echo "not found $keyword"
        ./exp/check_adb.exp $ip:$port
else
        echo "found:"
        echo $content

        # remove useless app
        ./adb -s $ip:$port uninstall com.cibn.tv
        ./adb -s $ip:$port uninstall com.assistant.tv.server
	echo `date +"%Y-%m-%d %H:%M:%S"` $ip " remove cibn">> remove_app.log
fi


keyword=/system/app/HiMarketTV*
echo -n "$ip   "
content=`./adb -s $ip:$port shell ls -l $keyword|grep -v "No such"`
found=$?
if [ $found -ne 0 ];then
        echo "not found $keyword"
        ./exp/check_adb.exp $ip:$port
else
        echo "found: $keyword"
        echo $content
        ./adb -s $ip:$port shell "mount -o remount,rw /system"
        ./adb -s $ip:$port shell "rm /system/app/HiMarketTV*"
        ./adb -s $ip:$port shell "mount -o remount,ro /system"
	echo `date +"%Y-%m-%d %H:%M:%S"` $ip " remove market">> remove_app.log
fi


 keyword=/system/framework/iepg.apk
       echo -e "now detect $keyword, Result is:"
        content=`./adb -s $ip:$port shell ls -l $keyword|grep -v "No such"`
         found=$?
	      if [ $found -ne 0 ];then
	               echo -e  "$keyword is not found!"
	                ./exp/check_adb.exp $ip:$port
	         else
		              echo "$keyword is existed and it will be removed!"
		               echo $content
		                ./adb -s $ip:$port shell "mount -o remount,rw /system"
		                 ./adb -s $ip:$port shell "rm /system/framework/iepg.apk"
			              ./adb -s $ip:$port shell "mount -o remount,ro /system"
			               ./adb -s $ip:$port shell "input keyevent 131"
			                ./adb -s $ip:$port shell "input keyevent 18"
			             echo `date +"%Y-%m-%d %H:%M:%S"` $ip " remove market">> remove_app.log
				      fi


./adb disconnect $ip:$port >> /dev/null
./exp/close_port.exp $ip $port


exit 0
