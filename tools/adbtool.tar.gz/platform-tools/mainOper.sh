#!/bin/bash

usage()
{
	echo -n 'Usage:'
	echo "$0  --type 1602/1200/7628/3050 -ip 172.16.52.58 -cmd ifconfig -w result.txt
      or $0 --type 1602/1200/7628/3050 -mcid 101 -cmd ifconfig -w result.txt
      or $0  --type 1602/1200/7628/3050 -ip 172.16.52.58 -sh /directory/script.sh -w result.txt
      or $0 --type 1602/1200/7628/3050 -mcid 101 -sh /directory/script.sh -w result.txt
      or $0 --type 1602/1200/7628/3050 -online -sh /directory/script.sh -w result.txt
      or $0 --type 1602/1200/7628/3050 -online -cmd ifconfig -w result.txt"
}

help()
{
	echo '      --type type of device,such as 1602,1200,7628,3050
      -ip  ip of device
      -mcid  value of mcid
      -online online of all device
      -cmd    input command
      -sh     input script
      -w      write output to a file
      -version the version of this script '
      echo " "
usage
} 
show_version()
{
        echo "version: 1.0"
        echo "create date: 2016-11-28"
}
get_ip_by_mcid()
{
#	echo "enter get ip by mcid $1"
	ip=`mysql -uroot -N sdb20 -e "select terminalipaddress from terminal where mcid="$1""`
	echo $ip
}

get_3050_ip_by_mcid()
{
#	echo "enter get ip by mcid $1"
	ip=`mysql -uroot -N sdb20 -e "select a.monitorwanip as monitorwanip from apinfo a,apterminalmap m,terminal t where a.apid=m.apid and m.terminalid=t.terminalid and mcid="$1""`
	echo $ip
}
if [ $# -lt 1 ]; then
  help
  exit 1
fi
LOG_FILE=oper.log
IPLIST=iplist.txt
W_FLAG=0
CMD_TYPE=0
FILENAME=result.txt
USERNAME="rootui"
PASSWORD="fw0169p!"
ARGS=`getopt -a -o vVw:h -l version,type:,ip:,mcid:,sh:,cmd:,online,help -- "$@"` 
[ $? -ne 0 ] && usage  
eval set -- "${ARGS}" 
echo "begin at `date +"%Y-%m-%d %H:%M:%S"`" > $LOG_FILE
while true  
do 
        case "$1" in 
        -v|-V|--version)  
              show_version;exit 0 
                ;;
		    --type)
				      TYPE=$2;shift 2
		  				;;
		  	-i|--ip)
				      IP=$2;FLAG=1;shift 2
		  				;;
		  	--mcid)
				      MCID=$2;FLAG=2;shift 2
		  				;;
		  	--cmd)
				      CMD=$2;CMD_TYPE=1;shift 2
		  				;;
		  	--sh)
				      SH=$2;CMD_TYPE=2;shift 2
		  				;;
		  	--online)
				      FLAG=3;shift
		  				;;
		  	-w)
				    FILENAME=$2;W_FLAG=1;shift 2
		  				;;
        -h|--help)  
                help
                exit 0
                ;;  
        --)  
                shift  
                break 
                ;;  
        esac  
 
done

if [ "$TYPE" == "" ]; then
	TYPE=1602
fi

#echo "get args:ip=$IP,cmd=$CMD,mcid=$MCID,single=$SINGLE,type=$TYPE,flag=$FLAG,sh=$SH,filename=$FILENAME"
if [ $FLAG -eq 1 ]; then
	 HOST=$IP
	 echo $HOST > $IPLIST
	 SINGLE=1
elif [ $FLAG -eq 2 ]; then
	if [ "$TYPE" == "3050" ];then
		 HOST=`get_3050_ip_by_mcid $MCID`
	else
     HOST=`get_ip_by_mcid $MCID`
  fi
	
	if [ "$HOST" == "" ];then
	   echo "get NULL ip by mcid:$MCID" |tee -a $LOG_FILE
	   exit 1
	fi
	echo "get ip by mcid host:$HOST"
	echo $HOST > $IPLIST
	SINGLE=1
elif [ $FLAG -eq 3 ]; then
	SINGLE=2
	if [ "$TYPE" == "3050" ];then
		  mysql -uroot -N sdb20 -e "select a.apmonitorwanip as monitorwanip from apinfo a,apterminalmap m,terminal t where a.apid=m.apid and m.terminalid=t.terminalid and (DATE_SUB(now(),INTERVAL 28920 SECOND)<=a.lastupdatetime) and a.type=1" > $IPLIST
	else
	    mysql -uroot -N sdb20 -e "select t.terminalipaddress from apinfo a,apterminalmap m,terminal t where t.isonline=1 and a.apid=m.apid and m.terminalid=t.terminalid and a.type=4" > $IPLIST
	fi
else
	echo "Invalid parameter, please input ip or mcid or online!" |tee -a $LOG_FILE
fi
echo "***************************************************" > $FILENAME
echo "*************COPYRIGHT of SUNLIGHT*****************" >> $FILENAME
echo "******Remote control android or linux device*******" >> $FILENAME
echo "***************************************************" >> $FILENAME
echo "" >> $FILENAME
port=5050
NUM=0
COUNT=0
NUM_PING_FAIL=0
NUM_ADB_FAIL=0
TOTAL=`wc -l $IPLIST |awk '{print \$1}'`
for HOST_IP in $(cat $IPLIST)
do
    if [ $SINGLE == 1 ];then
    	 HOST_IP=$HOST
       if [ $COUNT -gt 0 ];then
       	  break
       fi
    fi
    let COUNT++
  	echo "Now Operating  #$COUNT/$TOTAL $HOST_IP"
  	ping -c 2 $HOST_IP &>/dev/null
  	if [[ $? != 0 ]];then
     		echo "$HOST_IP is LOST"
		    echo "Operation terminated!"
        let NUM_PING_FAIL++
     		continue
    fi
    echo "**************************************************" >> $FILENAME
    echo "**`date +"%Y-%m-%d %H:%M:%S"` Operating host $HOST_IP**" >> $FILENAME
    echo "***************************************************" >> $FILENAME
    if [ "$TYPE" == "1602" ];then
    	./connectAndroid.exp $HOST_IP
    	 if [ $? -eq 1 ];then
		     echo "connect $HOST_IP failed!" |tee -a $LOG_FILE
		     continue
		   else
		     echo "connect $HOST_IP success!" |tee -a $LOG_FILE
	     fi
	    ./adb kill-server
	    ./adb devices
	    ./check_adb.exp $HOST_IP:$port
	    ret=$?
	    if [ $ret -ne 0 ];then
	        # something is wrong ...
		      echo "adb connect $HOST_IP failed,$ret" |tee -a $LOG_FILE
		  else
		      echo "adb connect $HOST_IP success,$ret" |tee -a $LOG_FILE
	    fi
	    if [ $CMD_TYPE -eq 1 ];then
			    if [ $W_FLAG -eq 1 ];then
			       ./adb shell $CMD >> $FILENAME
			    else
			       ./adb shell $CMD
			    fi
			    if [ $? -eq 0 ];then
				  	echo "execute adb cmd sucess" |tee -a $LOG_FILE
				  else
				    echo "execute adb cmd failed" |tee -a $LOG_FILE
				  fi
			elif [ $CMD_TYPE -eq 2 ];then
				  #echo "SH is $SH"
				  SH_FILE=${SH##*/}
				  	echo "SH FILE is $SH_FILE"
				  ./adb push $SH /data
				  if [ $? -eq 0 ];then
				  	echo "push $SH sucess" |tee -a $LOG_FILE
				  else
				    echo "push $SH failed" |tee -a $LOG_FILE
				    let NUM_ADB_FAIL++
				    continue
				  fi
				  ./adb shell chmod +x /data/$SH_FILE
			    if [ $W_FLAG -eq 2 ];then
			       ./adb shell /system/bin/sh /data/$SH_FILE >> $FILENAME
			    else
			       ./adb shell /system/bin/sh /data/$SH_FILE
			    fi
			    ret=$?
			    ./adb shell rm -rf /data/$SH_FILE
			    if [ $ret -eq 0 ];then
				  	echo "execute adb sh sucess" |tee -a $LOG_FILE
				  else
				    echo "execute adb sh failed" |tee -a $LOG_FILE
				    let NUM_ADB_FAIL++
				    continue
				  fi
			else
			    echo "Invalid cmd parameter" |tee -a $LOG_FILE
			fi
			./adb kill-server
	    if [ $? -ne 0 ];then
	    	echo "exe cmd $CMD failed!" |tee -a $LOG_FILE
	    fi
    elif [ "$TYPE" == "7628" ] || [ "$TYPE" == "1200" ] || [ "$TYPE" == "3050" ];then
    	 if [ "$TYPE" == "1200" ];then
    	 	  USERNAME="root"
          PASSWORD=""
       fi
    	 if [ $CMD_TYPE -eq 1 ];then   #input cmd
			    if [ $W_FLAG -eq 1 ];then
			       ./operLinuxCmd.exp $HOST_IP "$CMD" $USERNAME "$PASSWORD" >> $FILENAME
		
			    else
			       ./operLinuxCmd.exp $HOST_IP "$CMD" $USERNAME "$PASSWORD" 
			       
			    fi
			    echo "oper linux cmd result:$?"
			elif [ $CMD_TYPE -eq 2 ];then   #input sh script
				  if [ $W_FLAG -eq 1 ];then
              ./operLinuxSh.exp $HOST_IP $SH $USERNAME "$PASSWORD"  >> $FILENAME
          else
             ./operLinuxSh.exp  $HOST_IP $SH $USERNAME "$PASSWORD" 
          fi
          echo "oper linux script result:$?"
       else
          echo "Invalid cmd parameter" |tee -a $LOG_FILE
       fi
 	  else
	     echo "invalid TYPE operation"
	  fi
	 
	  rm -rf $IPLIST
	  
done

if [ $SINGLE -eq 2 ];then
    echo "***************SUMMARY***************"
    echo "The number of online STB:     $TOTAL"
    echo "The number of telnet fail:    $NUM_PING_FAIL"
    if [ "$TYPE" == "1602" ];then
        echo "The number of executing adb cmd fail:    $NUM_ADB_FAIL"
    fi
    echo "*************************************"
fi
