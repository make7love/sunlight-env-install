#!/bin/sh
IPLIST=iplist.txt

remove_package(){
	ip=$1
	keyword=cibn
	port=5050

	./adb kill-server
	./adb devices
	./exp/check_adb.exp $ip:$port
	ret=$?
	if [ $ret -eq 2 ];then
		echo "connect ret $ret"
		return 2
	fi

	if [ $ret -eq 1 ];then
		./exp/open_port.exp $ip $port
		if [ $? -eq 1 ];then
			echo -e "open adb port failed on $ip"
		    return 3
		fi
		./exp/check_adb.exp $ip:$port
		if [ $? -ne 0 ];then
		# something is wrong ...
			echo -e "connect $ip failed"
			return 4
		fi
	fi

	usleep 200000

	echo -e "now connect to $ip  ... "
	echo -e "now detect $keyword. And result is:"
	content=`./adb -s $ip:$port shell ps |grep $keyword`
	found=$?
	if [ $found -ne 0 ];then
			echo "$keyword is not found!"
			./exp/check_adb.exp $ip:$port
	else
			echo -e "$keyword is existed. And it will be removed!"
			echo -n $content

			# remove useless app
			./adb -s $ip:$port uninstall com.cibn.tv
			./adb -s $ip:$port uninstall com.assistant.tv.server
		echo `date +"%Y-%m-%d %H:%M:%S"` $ip " remove cibn">> remove_app.log
	fi


	keyword=/system/app/HiMarketTV*
	echo -e "now detect $keyword, Result is:"
	content=`./adb -s $ip:$port shell ls -l $keyword|grep -v "No such"`
	found=$?
	if [ $found -ne 0 ];then
			echo -e  "$keyword is not found!"
			./exp/check_adb.exp $ip:$port
	else
			echo "$keyword is existed and it will be removed!"
			echo $content
			./adb -s $ip:$port shell "mount -o remount,rw /system"
			./adb -s $ip:$port shell "rm /system/app/HiMarketTV*"
			./adb -s $ip:$port shell "mount -o remount,ro /system"
		echo `date +"%Y-%m-%d %H:%M:%S"` $ip " remove market">> remove_app.log
	fi
	
	keyword=/system/framework/iepg.apk
	echo -e "now detect $keyword, Result is:"
	content=`./adb -s $ip:$port shell ls -l $keyword|grep -v "No such"`
	found=$?
	if [ $found -ne 0 ];then
			echo -e  "$keyword is not found!"
			./exp/check_adb.exp $ip:$port
	else
			echo "$keyword is existed and it will be removed!"
			echo $content
			./adb -s $ip:$port shell "mount -o remount,rw /system"
			./adb -s $ip:$port shell "rm /system/framework/iepg.apk"
			./adb -s $ip:$port shell "mount -o remount,ro /system"
			./adb -s $ip:$port shell "input keyevent 131"
			./adb -s $ip:$port shell "input keyevent 18"
		echo `date +"%Y-%m-%d %H:%M:%S"` $ip " remove iepg">> remove_app.log
	fi


	./adb disconnect $ip:$port >> /dev/null
	./exp/close_port.exp $ip $port
}



checkitem="$0"
let procCnt=`ps -A --format='%p%P%C%x%a' --width 2048 -w --sort pid|grep "$checkitem"|grep -v grep|grep -v " -c sh "|grep -v "$$" | grep -c sh|awk '{printf("%d",$1)}'`
if [ ${procCnt} -gt 0 ] ; then 
    echo "$0 is running and it will not run again!!!"
    exit 1; 
fi

cd `dirname $0`

mysql -uroot -N sdb20 -e "select t.terminalipaddress from apinfo a,apterminalmap m,terminal t where t.isonline=1 and a.apid=m.apid and m.terminalid=t.terminalid and a.type=4" > $IPLIST


for HOST_IP in $(cat $IPLIST)
	do
       echo "now detect $HOST_IP and do something for it!!!"
	   sleep 1
	   remove_package $HOST_IP
	done

	
	
