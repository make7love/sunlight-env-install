#!/bin/sh

if [ $# -lt 2 ];then
	echo "$0 <ip> <path>"
	exit 1
fi

ip=$1
path=$2
port=5050
retcont=""

./exp/check_adb.exp $ip:$port
ret=$?
if [ $ret -eq 2 ];then
	echo "connect ret $ret"
	exit 2
fi

if [ $ret -eq 1 ];then
	./exp/open_port.exp $ip $port
	if [ $? -eq 1 ];then
		echo "open adb port failed on $ip"
		exit 3
	fi
	./exp/check_adb.exp $ip:$port
	if [ $? -ne 0 ];then
	# something is wrong ...
		echo "connect $ip failed"
		exit 4
	fi
fi

usleep 200000

echo "$ip"
retcont=`./adb -s $ip:$port shell ls -l $path`
./adb disconnect $ip:$port >> /dev/null

echo "$retcont"
echo ""


exit 0
