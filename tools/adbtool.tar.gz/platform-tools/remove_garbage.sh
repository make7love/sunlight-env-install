#!/bin/sh
IPLIST=iplist.txt

checkitem="$0"
let procCnt=`ps -A --format='%p%P%C%x%a' --width 2048 -w --sort pid|grep "$checkitem"|grep -v grep|grep -v " -c sh "|grep -v "$$" | grep -c sh|awk '{printf("%d",$1)}'`
if [ ${procCnt} -gt 0 ] ; then 
    echo "$0 is running and it will not run again!!!"
    exit 1; 
fi

cd `dirname $0`

mysql -uroot -N sdb20 -e "select t.terminalipaddress from apinfo a,apterminalmap m,terminal t where t.isonline=1 and a.apid=m.apid and m.terminalid=t.terminalid and a.type=4" > $IPLIST


for HOST_IP in $(cat $IPLIST)
	do
       echo $HOST_IP
	   sleep 2

	done
