#!/bin/sh

if [ $# -lt 2 ];then
	echo "$0 <ip> <keyword>"
	exit 1
fi

ip=$1
keyword=$2
port=5050

./exp/check_adb.exp $ip:$port
ret=$?
if [ $ret -eq 2 ];then
	echo "connect ret $ret"
	exit 2
fi

if [ $ret -eq 1 ];then
	./exp/open_port.exp $ip $port
	if [ $? -eq 1 ];then
		echo "open adb port failed on $ip"
		exit 3
	fi
	./exp/check_adb.exp $ip:$port
	if [ $? -ne 0 ];then
	# something is wrong ...
		echo "connect $ip failed"
		exit 4
	fi
fi

usleep 200000

echo -n "$ip   "
content=`./adb -s $ip:$port shell ps |grep $keyword`
found=$?
./adb disconnect $ip:$port >> /dev/null
if [ $found -ne 0 ];then
	echo "not found"
	exit 11
fi

echo "found:"
echo $content


exit 0
