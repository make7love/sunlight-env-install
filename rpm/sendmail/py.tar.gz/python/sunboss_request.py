#!/usr/bin/env python
# -*- coding:utf-8 -*-

import requests
import random
import multiprocessing



stb_usr_id = [6100,6103,6107,6108,6109,6110,6111,6112,6113,6114,6115,6119,6120,6130,6131,6133,6134,6202,6203,6207,6209
,6210,6211,6212,6213,6214,6215,6216,6217,6218,6222,6223,6225,6226,6227,6229,6230,7100,7103,7107]

stb_auth_url = "http://10.108.144.5/app/doauth.php?userid="

stb_auth_redirect_url = "http://10.108.144.5/ihotel_hd_01/index.php?userID=26207&epgGroupID=1&rootCategoryID=1"

stb_data_url = "http://10.108.144.5/epgservice/index.php"


request_data_01='''
{
	"Message":{
		"MessageType":"GetSysParamReq",
		"MessageBody":{
			"ParamList":{
			"Param":[
				{"Name":"bg_media_url"},
				{"Name":"vod_url_prefix"},
				{"Name":"epg_theme_type"},
				{"Name":"welcome_page_show_wifi_flag"},
				{"Name":"startup_ad_enable"},
				{"Name":"welcomepage_pre_ad_key_controlable"},
				{"Name":"vod_pre_ad_prohibited"},
				{"Name":"dvb_running_mode"},
				{"Name":"image_gallery_show_duration"},
				{"Name":"screensaver_waiting_time"},
				{"Name":"screensaver_staus"}
				]
			}
		}
	}
}
'''

request_data_02 = '''
{
    "Message": {
        "MessageType": "GetStartupAdReq",
        "MessageBody": {
            "EpgGroupID": 1,
            "LangCode": "chi"
        }
    }
}
'''


request_data_03 = """
{
    "Message": {
        "MessageType": "GetSysTimeReq",
        "MessageBody": {
            "UserID": "Reqeust_Stb_User_Id"
        }
    }
}
"""

request_data_04 = '''
{
    "Message": {
        "MessageType": "GetShortcutInfoReq",
        "MessageBody": {
            "UserID": "Reqeust_Stb_User_Id"
        }
    }
}
'''

request_data_05 = '''
{
    "Message": {
        "MessageType": "GetWelcomePageReq",
        "MessageBody": {
            "UserID": "Reqeust_Stb_User_Id",
            "EpgGroupID": "1"
        }
    }
}
'''

request_data_06 = '''
{
 "Message": {
        "MessageType": "GetHereWeatherInfoReq",
        "MessageBody": {
            "EpgGroupID": "1",
            "LangCode": "chi"
        }
    }
}
'''

request_data_08 = '''
{
    "Message": {
        "MessageType": "GetSysParamReq",
        "MessageBody": {
            "ParamList": {
                "Param": [
                    {
                        "Name": "welcome_bg_media_url"
                    },
                    {
                        "Name": "epg_theme_type"
                    },
                    {
                        "Name": "welcome_page_show_wifi_flag"
                    }
                ]
            }
        }
    }
}
'''

request_data_09 = '''
{
    "Message": {
        "MessageType": "GetRoomMsgReq",
        "MessageBody": {
            "UserID": "Reqeust_Stb_User_Id",
            "LangCode": "chi"
        }
    }
}
'''

request_data_10 = '''
{
    "Message": {
        "MessageType": "GetObjectInfoReq",
        "MessageBody": {
            "ObjectID": "1",
            "ObjectType": "1",
            "ChildrenLevel": "2",
            "LangCode": "chi",
            "EpgGroupID": "1",
            "UserID": "Reqeust_Stb_User_Id"
        }
    }
}
'''


request_data_11 = '''
{
    "Message": {
        "MessageType": "GetRoomMsgBoxReq",
        "MessageBody": {
            "UserID": "Reqeust_Stb_User_Id"
        }
    }
}
'''

def send_request(url,md,datas=None):
	if md == 'get':
		r = requests.get(url, params=datas)
	else:
		r = requests.post(url,data=datas)
	
	print r.text

	
def request_run():
	global stb_usr_id
	global request_data_03 , request_data_04 , request_data_05 , request_data_09 , request_data_10 , request_data_11
	global stb_auth_url
	
	#lock.acquire()
	user_id = random.choice(stb_usr_id)
	#lock.release()
	 
	if user_id : 
		while True:
			request_data_03 = request_data_03.replace("Reqeust_Stb_User_Id",str(user_id))
			request_data_04 = request_data_04.replace("Reqeust_Stb_User_Id",str(user_id))
			request_data_05 = request_data_05.replace("Reqeust_Stb_User_Id",str(user_id))
			request_data_09 = request_data_09.replace("Reqeust_Stb_User_Id",str(user_id))
			request_data_10 = request_data_10.replace("Reqeust_Stb_User_Id",str(user_id))
			request_data_11 = request_data_11.replace("Reqeust_Stb_User_Id",str(user_id))
			
			stb_auth_url = stb_auth_url + str(user_id)
			#登录；
			#print "-------------------登录-------------------"
			#send_request(stb_auth_url,'get')
			
			#send_request(stb_data_url,'post',request_data_03)
			print "-------------------获取系统参数-------------------"
			send_request(stb_data_url,'post',request_data_01)
			
			print "-------------------获取开机广告-------------------"
			send_request(stb_data_url,'post',request_data_02)
			
			print "-------------------获取系统时间-------------------"
			send_request(stb_data_url,'post',request_data_03)
			
			print "-------------------获取短标信息-------------------"
			send_request(stb_data_url,'post',request_data_04)
			
			print "-------------------获取欢迎页-------------------"
			send_request(stb_data_url,'post',request_data_05)
			
			print "-------------------获取天气信息-------------------"
			send_request(stb_data_url,'post',request_data_06)
			
			print "-------------------获取背景视频-------------------"
			send_request(stb_data_url,'post',request_data_08)
			
			print "-------------------获取房间信息-------------------"
			send_request(stb_data_url,'post',request_data_09)
			
			print "-------------------获取菜单信息-------------------"
			send_request(stb_data_url,'post',request_data_10)
			
			print "-------------------获取留言消息-------------------"
			send_request(stb_data_url,'post',request_data_11)
		

def create_process():
	lock = multiprocessing.Lock()
	for i in range(1,310):
		p = multiprocessing.Process(target = request_run,args=())
		p.start()
	
	#s_pools = multiprocessing.Pool(processes = 10)
	#for i in range(1,11):
	#	s_pools.apply_async(request_run,(lock))
	

	
	
def main():
	#create_process()
	request_run()
	
	
	
	
if __name__ == '__main__':
	main()
